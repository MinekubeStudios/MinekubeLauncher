mod content;
pub use self::content::*;

mod model;
pub use self::model::*;
pub(crate) use self::model::{StoredOption, StoredPreference};

pub(crate) mod adapters;
pub(crate) mod commands;
pub use self::commands::{
    AppliedContentSetPatch, CreateInstance, EditInstance,
    InstanceLaunchOverridesPatch, InstanceMetadata,
};
pub(crate) use self::commands::{
    attach_shared_instance, clear_shared_instance, quarantine_shared_instance,
    set_shared_instance_sync_status,
};
pub(crate) use self::commands::{
    create_instance, edit_instance, get_instance, get_instances_metadata,
    list_instances, refresh_all_instances, remove_instance,
};
pub(crate) use self::commands::{
    dependencies_to_content_items, get_content_projects,
    get_installed_project_ids_for_instance, get_instance_install_candidates,
    get_linked_modpack_info, list_content, list_content_sets,
    list_linked_modpack_content, refresh_content_updates, sync_content_files,
};
pub(crate) use self::commands::{
    game_options_sync_is_enabled, load_game_option_preferences,
    load_game_options_sync_state, load_shared_game_options,
    shared_game_options_exist,
};
pub(crate) mod watcher;

pub(crate) use adapters::sqlite::content_rows::{
    get_instance_file_by_relative_path, get_instance_files,
    upsert_instance_file,
};
pub(crate) use adapters::sqlite::instance_rows::list_instances as load_instance_rows;
