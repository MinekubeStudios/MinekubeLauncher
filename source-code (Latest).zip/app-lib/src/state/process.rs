use crate::event::ProcessPayloadType;
use crate::event::emit::emit_process;
#[cfg(feature = "tauri")]
use crate::event::{LogEvent, LogPayload};
use crate::util::io::IOError;
use crate::util::rpc::RpcServer;
use chrono::{DateTime, TimeZone, Utc};
use dashmap::DashMap;
use quick_xml::Reader;
use quick_xml::events::Event;
use serde::Deserialize;
use serde::Serialize;
use std::collections::VecDeque;
use std::fmt::Debug;
use std::fs::OpenOptions;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::ExitStatus;
use std::sync::LazyLock;
use std::time::Instant;
use tempfile::TempDir;
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::process::{Child, Command};
use uuid::Uuid;

const LAUNCHER_LOG_PATH: &str = "launcher_log.txt";
const LOG_BUFFER_CAPACITY: usize = 50_000;

struct LogRingBuffer {
    lines: VecDeque<String>,
}

impl LogRingBuffer {
    fn new() -> Self {
        Self {
            lines: VecDeque::new(),
        }
    }

    fn push(&mut self, line: String) {
        if self.lines.len() >= LOG_BUFFER_CAPACITY {
            self.lines.pop_front();
        }
        self.lines.push_back(line);
    }

    fn get_all(&self) -> Vec<String> {
        self.lines.iter().cloned().collect()
    }

    fn clear(&mut self) {
        self.lines.clear();
    }
}

static LOG_BUFFERS: LazyLock<DashMap<String, LogRingBuffer>> =
    LazyLock::new(DashMap::new);

pub fn push_log_line(instance_id: &str, line: String) {
    LOG_BUFFERS
        .entry(instance_id.to_string())
        .or_insert_with(LogRingBuffer::new)
        .push(line);
}

pub fn get_log_buffer(instance_id: &str) -> Vec<String> {
    LOG_BUFFERS
        .get(instance_id)
        .map(|buf| buf.get_all())
        .unwrap_or_default()
}

pub fn clear_log_buffer(instance_id: &str) {
    if let Some(mut buf) = LOG_BUFFERS.get_mut(instance_id) {
        buf.clear();
    }
}

pub fn remove_log_buffer(instance_id: &str) {
    LOG_BUFFERS.remove(instance_id);
}

pub fn has_minecraft_window_log(instance_id: &str) -> bool {
    let Some(buf) = LOG_BUFFERS.get(instance_id) else {
        return false;
    };
    buf.lines.iter().any(|line| {
        line.contains("Backend library: LWJGL")
            || line.contains("LWJGL Version:")
            || line.contains("OpenAL initialized")
            || line.contains("Sound engine started")
            || line.contains("Narrator library")
            || (line.contains("Created:") && line.contains("textures/atlas"))
    })
}

async fn clear_persisted_process(
    state: &crate::State,
    process: Option<(i64, i64)>,
) {
    let Some((pid, start_time)) = process else {
        return;
    };
    if let Err(error) = sqlx::query!(
        "DELETE FROM processes WHERE pid = ? AND start_time = ?",
        pid,
        start_time,
    )
    .execute(&state.pool)
    .await
    {
        tracing::warn!("Failed to clear persisted process {pid}: {error}");
    }
}

/// Whether the OS process `pid` is still the one that was started at
/// `start_time` (a reused pid belongs to some other program).
fn persisted_process_alive(pid: u32, start_time: i64) -> bool {
    let target = sysinfo::Pid::from_u32(pid);
    let mut system = sysinfo::System::new();
    system.refresh_processes(sysinfo::ProcessesToUpdate::Some(&[target]), true);
    system.process(target).is_some_and(|process| {
        (process.start_time() as i64).abs_diff(start_time) <= 2
    })
}

pub(crate) async fn instance_has_running_process(
    instance_id: &str,
    state: &crate::State,
) -> crate::Result<bool> {
    if state
        .process_manager
        .get_all()
        .iter()
        .any(|process| process.instance_id == instance_id)
    {
        return Ok(true);
    }

    let processes = sqlx::query!(
        "
		SELECT pid, start_time
		FROM processes
		WHERE instance_id = ?
		",
        instance_id,
    )
    .fetch_all(&state.pool)
    .await?;
    if processes.is_empty() {
        return Ok(false);
    }
    let mut running = false;
    for process in processes {
        let process_is_running = u32::try_from(process.pid)
            .is_ok_and(|pid| persisted_process_alive(pid, process.start_time));
        if process_is_running {
            running = true;
        } else {
            clear_persisted_process(
                state,
                Some((process.pid, process.start_time)),
            )
            .await;
        }
    }
    Ok(running)
}

pub struct ProcessManager {
    processes: DashMap<Uuid, Process>,
    /// Games started by an earlier session of the launcher that are still
    /// running. The launcher no longer owns their `Child`, so they are watched
    /// by pid instead, but they count as running everywhere else.
    detached: DashMap<Uuid, DetachedProcess>,
}

#[derive(Debug, Clone)]
struct DetachedProcess {
    metadata: ProcessMetadata,
    pid: u32,
    start_time: i64,
}

/// How often a game from an earlier launcher session is checked for exit.
const DETACHED_POLL_INTERVAL: std::time::Duration =
    std::time::Duration::from_secs(2);

impl Default for ProcessManager {
    fn default() -> Self {
        Self::new()
    }
}

impl ProcessManager {
    pub fn new() -> Self {
        Self {
            processes: DashMap::new(),
            detached: DashMap::new(),
        }
    }

    /// Re-attaches games that are still running from an earlier launcher
    /// session, so closing and reopening the launcher keeps showing them as
    /// running (with a working Stop button). Rows of games that have exited in
    /// the meantime are removed.
    pub async fn restore_persisted_processes(&self, pool: &sqlx::SqlitePool) {
        use sqlx::Row;

        let rows = match sqlx::query(
            "
			SELECT processes.pid, processes.start_time, processes.instance_id,
				instances.path, instances.name
			FROM processes
			INNER JOIN instances ON instances.id = processes.instance_id
			",
        )
        .fetch_all(pool)
        .await
        {
            Ok(rows) => rows,
            Err(error) => {
                tracing::warn!("Failed to read running games: {error}");
                return;
            }
        };

        for row in rows {
            let (Ok(pid), Ok(start_time), Ok(instance_id), Ok(path), Ok(name)) = (
                row.try_get::<i64, _>("pid"),
                row.try_get::<i64, _>("start_time"),
                row.try_get::<String, _>("instance_id"),
                row.try_get::<String, _>("path"),
                row.try_get::<String, _>("name"),
            ) else {
                continue;
            };
            let Ok(os_pid) = u32::try_from(pid) else {
                continue;
            };
            if !persisted_process_alive(os_pid, start_time) {
                let _ = sqlx::query(
                    "DELETE FROM processes WHERE pid = ? AND start_time = ?",
                )
                .bind(pid)
                .bind(start_time)
                .execute(pool)
                .await;
                continue;
            }

            let metadata = ProcessMetadata {
                uuid: Uuid::new_v4(),
                instance_id,
                instance_path: path,
                instance_name: name,
                start_time: Utc
                    .timestamp_opt(start_time, 0)
                    .single()
                    .unwrap_or_else(Utc::now),
                pid: Some(os_pid),
            };
            let uuid = metadata.uuid;
            tracing::info!(
                "Re-attached running game of instance {} (pid {os_pid})",
                metadata.instance_id
            );
            self.detached.insert(
                uuid,
                DetachedProcess {
                    metadata,
                    pid: os_pid,
                    start_time,
                },
            );
            tokio::spawn(Self::watch_detached(uuid));
        }
    }

    /// Waits for a re-attached game to exit, then cleans up exactly like a game
    /// launched in this session.
    async fn watch_detached(uuid: Uuid) {
        let state = match crate::State::get().await {
            Ok(state) => state,
            Err(error) => {
                tracing::warn!("Cannot watch re-attached game: {error}");
                return;
            }
        };
        loop {
            let Some(process) =
                state.process_manager.detached.get(&uuid).map(|p| p.clone())
            else {
                return;
            };
            if !persisted_process_alive(process.pid, process.start_time) {
                state.process_manager.detached.remove(&uuid);
                clear_persisted_process(
                    &state,
                    Some((i64::from(process.pid), process.start_time)),
                )
                .await;
                let _ = emit_process(
                    &process.metadata.instance_id,
                    uuid,
                    ProcessPayloadType::Finished,
                    "Exited process",
                )
                .await;
                let _ = state.discord_rpc.clear_activity().await;
                return;
            }
            tokio::time::sleep(DETACHED_POLL_INTERVAL).await;
        }
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn insert_new_process(
        &self,
        instance_id: &str,
        instance_path: &str,
        instance_name: &str,
        mut mc_command: Command,
        post_exit_command: Option<String>,
        post_exit_env_vars: Vec<(String, String)>,
        logs_folder: PathBuf,
        xml_logging: bool,
        main_class_keep_alive: TempDir,
        rpc_server: Option<RpcServer>,
        post_process_init: impl AsyncFnOnce(
            &ProcessMetadata,
            &RpcServer,
        ) -> crate::Result<()>,
    ) -> crate::Result<ProcessMetadata> {
        mc_command.stdout(std::process::Stdio::piped());
        mc_command.stderr(std::process::Stdio::piped());
        mc_command.stdin(std::process::Stdio::piped());
        let executable = mc_command
            .as_std()
            .get_program()
            .to_string_lossy()
            .into_owned();

        if !logs_folder.exists() {
            tokio::fs::create_dir_all(&logs_folder)
                .await
                .map_err(|e| IOError::with_path(e, &logs_folder))?;
        }

        let log_path = logs_folder.join(LAUNCHER_LOG_PATH);

        clear_log_buffer(instance_id);

        {
            let mut log_file = OpenOptions::new()
                .write(true)
                .create(true)
                .truncate(true)
                .open(&log_path)
                .map_err(|e| IOError::with_path(e, &log_path))?;

            let now = chrono::Local::now();
            writeln!(
                log_file,
                "# Minecraft launcher log started at {}",
                now.format("%Y-%m-%d %H:%M:%S")
            )
            .map_err(|e| IOError::with_path(e, &log_path))?;
            writeln!(log_file, "# Instance: {instance_path} \n")
                .map_err(|e| IOError::with_path(e, &log_path))?;
            writeln!(log_file).map_err(|e| IOError::with_path(e, &log_path))?;
        }

        let mut mc_proc = mc_command.spawn().map_err(IOError::from)?;
        let child_pid = mc_proc.id();

        let stdout = mc_proc.stdout.take();
        let stderr = mc_proc.stderr.take();

        let mut process = Process {
            metadata: ProcessMetadata {
                uuid: Uuid::new_v4(),
                start_time: Utc::now(),
                instance_id: instance_id.to_string(),
                instance_path: instance_path.to_string(),
                instance_name: instance_name.to_string(),
                pid: child_pid,
            },
            child: mc_proc,
            rpc_server,
            _main_class_keep_alive: main_class_keep_alive,
        };

        let state = match crate::State::get().await {
            Ok(state) => state,
            Err(error) => {
                let _ = process.child.kill().await;
                return Err(error);
            }
        };
        let persisted_process = child_pid.map(|pid| {
            (i64::from(pid), process.metadata.start_time.timestamp())
        });
        if let Some((pid, start_time)) = persisted_process {
            let post_exit_command = post_exit_command.as_deref();
            if let Err(error) = sqlx::query!(
                "
				INSERT INTO processes
					(pid, start_time, name, executable, instance_id,
					 post_exit_command)
				VALUES (?, ?, ?, ?, ?, ?)
				ON CONFLICT(pid) DO UPDATE SET
					start_time = excluded.start_time,
					name = excluded.name,
					executable = excluded.executable,
					instance_id = excluded.instance_id,
					post_exit_command = excluded.post_exit_command
				",
                pid,
                start_time,
                instance_name,
                executable,
                instance_id,
                post_exit_command,
            )
            .execute(&state.pool)
            .await
            {
                let _ = process.child.kill().await;
                return Err(error.into());
            }
        }

        if let Some(rpc_server) = &process.rpc_server
            && let Err(e) = post_process_init(&process.metadata, rpc_server).await
        {
            tracing::error!("Failed to run post-process init: {e}");
            clear_persisted_process(&state, persisted_process).await;
            let _ = process.child.kill().await;
            return Err(e);
        }

        let metadata = process.metadata.clone();

        if let Some(stdout) = stdout {
            let log_path_clone = log_path.clone();

            let instance_id = metadata.instance_id.clone();
            let instance_path = metadata.instance_path.clone();
            tokio::spawn(async move {
                Process::process_output(
                    &instance_id,
                    &instance_path,
                    stdout,
                    log_path_clone,
                    xml_logging,
                )
                .await;
            });
        }

        if let Some(stderr) = stderr {
            let log_path_clone = log_path.clone();

            let instance_id = metadata.instance_id.clone();
            let instance_path = metadata.instance_path.clone();
            tokio::spawn(async move {
                Process::process_output(
                    &instance_id,
                    &instance_path,
                    stderr,
                    log_path_clone,
                    xml_logging,
                )
                .await;
            });
        }

        self.processes.insert(process.metadata.uuid, process);

        tokio::spawn(Process::sequential_process_manager(
            instance_id.to_string(),
            instance_path.to_string(),
            post_exit_command,
            post_exit_env_vars,
            metadata.uuid,
            persisted_process,
        ));

        emit_process(
            instance_id,
            metadata.uuid,
            ProcessPayloadType::Launched,
            "Launched Minecraft",
        )
        .await?;

        Ok(metadata)
    }

    pub fn get(&self, id: Uuid) -> Option<ProcessMetadata> {
        self.processes
            .get(&id)
            .map(|x| x.metadata.clone())
            .or_else(|| self.detached.get(&id).map(|x| x.metadata.clone()))
    }

    pub fn get_rpc(&self, id: Uuid) -> Option<RpcServer> {
        self.processes.get(&id).and_then(|x| x.rpc_server.clone())
    }

    pub fn get_all(&self) -> Vec<ProcessMetadata> {
        self.processes
            .iter()
            .map(|x| x.value().metadata.clone())
            .chain(self.detached.iter().map(|x| x.value().metadata.clone()))
            .collect()
    }

    pub fn try_wait(
        &self,
        id: Uuid,
    ) -> crate::Result<Option<Option<ExitStatus>>> {
        if let Some(mut process) = self.processes.get_mut(&id) {
            Ok(Some(process.child.try_wait()?))
        } else {
            Ok(None)
        }
    }

    pub async fn wait_for(&self, id: Uuid) -> crate::Result<()> {
        if let Some(mut process) = self.processes.get_mut(&id) {
            process.child.wait().await?;
            return Ok(());
        }
        while self.detached.contains_key(&id) {
            tokio::time::sleep(DETACHED_POLL_INTERVAL).await;
        }
        Ok(())
    }

    pub async fn kill(&self, id: Uuid) -> crate::Result<()> {
        if let Some(mut process) = self.processes.get_mut(&id) {
            process.child.kill().await?;
            return Ok(());
        }

        let detached = self.detached.get(&id).map(|p| (p.pid, p.start_time));
        if let Some((pid, start_time)) = detached
            && persisted_process_alive(pid, start_time)
        {
            let target = sysinfo::Pid::from_u32(pid);
            let mut system = sysinfo::System::new();
            system.refresh_processes(
                sysinfo::ProcessesToUpdate::Some(&[target]),
                true,
            );
            if let Some(process) = system.process(target) {
                process.kill();
            }
        }

        Ok(())
    }

    fn remove(&self, id: Uuid) {
        self.processes.remove(&id);
    }
}

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct ProcessMetadata {
    pub uuid: Uuid,
    pub instance_id: String,
    pub instance_path: String,
    pub instance_name: String,
    pub start_time: DateTime<Utc>,
    #[serde(default)]
    pub pid: Option<u32>,
}

#[derive(Debug)]
struct Process {
    metadata: ProcessMetadata,
    child: Child,
    _main_class_keep_alive: TempDir,
    rpc_server: Option<RpcServer>,
}

#[derive(Debug, Default, Serialize, Deserialize, Clone)]
#[cfg_attr(
    feature = "export-ts",
    derive(ts_rs::TS, postcard_bindgen::PostcardBindings)
)]
pub struct Log4jEvent {
    pub timestamp_millis: Option<i64>,
    pub logger_name: Option<String>,
    pub level: Option<String>,
    pub thread_name: Option<String>,
    pub message: Option<String>,
    pub throwable: Option<String>,
}

impl Process {
    async fn process_output<R>(
        instance_id: &str,
        _instance_path: &str,
        reader: R,
        log_path: impl AsRef<Path>,
        xml_logging: bool,
    ) where
        R: tokio::io::AsyncRead + Unpin,
    {
        let mut buf_reader = BufReader::new(reader);

        if xml_logging {
            let mut reader = Reader::from_reader(buf_reader);
            reader.config_mut().enable_all_checks(false);

            let mut buf = Vec::new();
            let mut current_event = Log4jEvent::default();
            let mut in_event = false;
            let mut in_message = false;
            let mut in_throwable = false;
            let mut current_content = String::new();

            loop {
                match reader.read_event_into_async(&mut buf).await {
                    Err(e) => {
                        tracing::error!(
                            "Error at position {}: {:?}",
                            reader.buffer_position(),
                            e
                        );
                        break;
                    }
                    // exits the loop when reaching end of file
                    Ok(Event::Eof) => break,

                    Ok(Event::Start(e)) => {
                        match e.name().as_ref() {
                            b"log4j:Event" => {
                                // Reset for new event
                                current_event = Log4jEvent::default();
                                in_event = true;

                                // Extract attributes
                                for attr in e.attributes().flatten() {
                                    let key = String::from_utf8_lossy(
                                        attr.key.into_inner(),
                                    )
                                    .to_string();
                                    let value =
                                        String::from_utf8_lossy(&attr.value)
                                            .to_string();

                                    match key.as_str() {
                                        "logger" => {
                                            current_event.logger_name =
                                                Some(value)
                                        }
                                        "level" => {
                                            current_event.level = Some(value)
                                        }
                                        "thread" => {
                                            current_event.thread_name =
                                                Some(value)
                                        }
                                        "timestamp" => {
                                            current_event.timestamp_millis =
                                                value.parse::<i64>().ok()
                                        }
                                        _ => {}
                                    }
                                }
                            }
                            b"log4j:Message" => {
                                in_message = true;
                                current_content = String::new();
                            }
                            b"log4j:Throwable" => {
                                in_throwable = true;
                                current_content = String::new();
                            }
                            _ => {}
                        }
                    }
                    Ok(Event::End(e)) => {
                        match e.name().as_ref() {
                            b"log4j:Message" => {
                                in_message = false;
                                current_event.message =
                                    Some(current_content.clone());
                            }
                            b"log4j:Throwable" => {
                                in_throwable = false;
                                current_event.throwable =
                                    if current_content.is_empty() {
                                        None
                                    } else {
                                        Some(current_content.clone())
                                    };

                                // Write log entry + throwable to file
                                if let Some(formatted_log) =
                                    Self::format_log4j_entry(&current_event)
                                {
                                    if let Err(e) = Process::append_to_log_file(
                                        &log_path,
                                        &formatted_log,
                                    ) {
                                        tracing::error!(
                                            "Failed to write to log file: {}",
                                            e
                                        );
                                    }

                                    if let Some(ref throwable) =
                                        current_event.throwable
                                        && let Err(e) =
                                            Process::append_to_log_file(
                                                &log_path, throwable,
                                            )
                                    {
                                        tracing::error!(
                                            "Failed to write throwable to log file: {}",
                                            e
                                        );
                                    }
                                }

                                Self::emit_log4j_event(
                                    instance_id,
                                    &current_event,
                                );
                            }
                            b"log4j:Event" => {
                                in_event = false;
                                // If no throwable was present, write the log entry at the end of the event
                                if current_event.message.is_some()
                                    && current_event.throwable.is_none()
                                {
                                    if let Some(formatted_log) =
                                        Self::format_log4j_entry(&current_event)
                                        && let Err(e) =
                                            Process::append_to_log_file(
                                                &log_path,
                                                &formatted_log,
                                            )
                                    {
                                        tracing::error!(
                                            "Failed to write to log file: {}",
                                            e
                                        );
                                    }

                                    Self::emit_log4j_event(
                                        instance_id,
                                        &current_event,
                                    );
                                }
                            }
                            _ => {}
                        }
                    }
                    Ok(Event::Text(mut e)) => {
                        if in_message || in_throwable {
                            if let Ok(text) = e.xml_content() {
                                current_content.push_str(&text);
                            }
                        } else if !in_event
                            && !e.inplace_trim_end()
                            && !e.inplace_trim_start()
                            && let Ok(text) = e.xml_content()
                        {
                            if let Err(e) = Process::append_to_log_file(
                                &log_path,
                                &format!("{text}\n"),
                            ) {
                                tracing::error!(
                                    "Failed to write to log file: {}",
                                    e
                                );
                            }
                            Self::emit_legacy_log(instance_id, &text);
                        }
                    }
                    Ok(Event::CData(e)) => {
                        if (in_message || in_throwable)
                            && let Ok(text) = e.xml_content()
                        {
                            current_content.push_str(&text);
                        }
                    }
                    _ => (),
                }

                buf.clear();
            }
        } else {
            let mut line = String::new();

            while let Ok(bytes_read) = buf_reader.read_line(&mut line).await {
                if bytes_read == 0 {
                    break; // End of stream
                }

                if !line.is_empty() {
                    if let Err(e) = Self::append_to_log_file(&log_path, &line) {
                        tracing::warn!("Failed to write to log file: {}", e);
                    }
                    Self::emit_legacy_log(instance_id, line.trim_ascii_end());
                }

                line.clear();
            }
        }
    }

    fn format_timestamp(timestamp_millis: Option<i64>) -> String {
        if let Some(timestamp_val) = timestamp_millis {
            let datetime_utc = if timestamp_val > i32::MAX as i64 {
                let secs = timestamp_val / 1000;
                let nsecs = ((timestamp_val % 1000) * 1_000_000) as u32;

                chrono::DateTime::<Utc>::from_timestamp(secs, nsecs)
                    .unwrap_or_default()
            } else {
                chrono::DateTime::<Utc>::from_timestamp_secs(timestamp_val)
                    .unwrap_or_default()
            };

            let datetime_local = datetime_utc.with_timezone(&chrono::Local);
            format!("[{}]", datetime_local.format("%H:%M:%S"))
        } else {
            "[??:??:??]".to_string()
        }
    }

    fn format_log4j_entry(event: &Log4jEvent) -> Option<String> {
        let message = event.message.as_ref()?;
        let thread = event.thread_name.as_deref().unwrap_or("");
        let level = event.level.as_deref().unwrap_or("");
        let logger = event.logger_name.as_deref().unwrap_or("");
        let formatted_time = Self::format_timestamp(event.timestamp_millis);

        Some(format!(
            "{} [{}] [{}{}]: {}\n",
            formatted_time,
            thread,
            if !logger.is_empty() {
                format!("{logger}/")
            } else {
                String::new()
            },
            level,
            message.trim()
        ))
    }

    fn emit_log4j_event(instance_id: &str, event: &Log4jEvent) {
        if let Some(formatted) = Self::format_log4j_entry(event) {
            push_log_line(instance_id, formatted.trim_end().to_string());
        }
        if let Some(ref throwable) = event.throwable {
            for line in throwable.lines().filter(|l| !l.is_empty()) {
                push_log_line(instance_id, line.to_string());
            }
        }

        #[cfg(feature = "tauri")]
        {
            let event_state = crate::EventState::get();
            let _ = event_state.send(crate::event::AppEvent::Log(LogPayload {
                instance_id: instance_id.to_string(),
                event: LogEvent::Log4j(event.clone()),
            }));
        }
        #[cfg(not(feature = "tauri"))]
        {
            let _ = (instance_id, event);
        }
    }

    fn emit_legacy_log(instance_id: &str, message: &str) {
        push_log_line(instance_id, message.to_string());

        #[cfg(feature = "tauri")]
        {
            let event_state = crate::EventState::get();
            let _ = event_state.send(crate::event::AppEvent::Log(LogPayload {
                instance_id: instance_id.to_string(),
                event: LogEvent::Legacy {
                    message: message.to_string(),
                },
            }));
        }
        #[cfg(not(feature = "tauri"))]
        {
            let _ = (instance_id, message);
        }
    }

    fn append_to_log_file(
        path: impl AsRef<Path>,
        line: &str,
    ) -> std::io::Result<()> {
        let mut file =
            OpenOptions::new().append(true).create(true).open(path)?;

        file.write_all(line.as_bytes())?;
        Ok(())
    }

    // Spawns a new child process and inserts it into the hashmap
    // Also, as the process ends, it spawns the follow-up process if it exists
    // By convention, ExitStatus is last command's exit status, and we exit on the first non-zero exit status
    async fn sequential_process_manager(
        instance_id: String,
        instance_path: String,
        post_exit_command: Option<String>,
        post_exit_env_vars: Vec<(String, String)>,
        uuid: Uuid,
        persisted_process: Option<(i64, i64)>,
    ) -> crate::Result<()> {
        async fn update_playtime(
            last_updated_playtime: &mut Instant,
            instance_id: &str,
            force_update: bool,
        ) {
            let elapsed = last_updated_playtime.elapsed().as_secs();
            if elapsed == 0 || (!force_update && elapsed < 60) {
                return;
            }

            let state = match crate::State::get().await {
                Ok(state) => state,
                Err(e) => {
                    tracing::warn!(
                        "Failed to get state for playtime update on instance {}: {}",
                        instance_id,
                        e
                    );
                    return;
                }
            };
            if let Err(e) =
                crate::state::instances::commands::add_instance_recent_playtime(
                    instance_id,
                    elapsed,
                    &state.pool,
                )
                .await
            {
                tracing::warn!(
                    "Failed to update playtime for instance {}: {}",
                    instance_id,
                    e
                );
            }
            *last_updated_playtime = Instant::now();
        }

        // Wait on current Minecraft Child
        let mc_exit_status;
        let mut last_updated_playtime = Instant::now();

        let state = crate::State::get().await?;
        loop {
            if let Some(process) = state.process_manager.try_wait(uuid)? {
                if let Some(t) = process {
                    mc_exit_status = t;
                    break;
                }
            } else {
                mc_exit_status = ExitStatus::default();
                break;
            }

            // sleep for 10ms
            tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;

            // Auto-update playtime every minute
            update_playtime(&mut last_updated_playtime, &instance_id, false)
                .await;
        }

        state.process_manager.remove(uuid);
        clear_persisted_process(&state, persisted_process).await;
        let sync_instance_id = instance_id.clone();
        tokio::spawn(async move {
            if let Err(error) =
                crate::api::instance::reconcile_instance_synced_options(
                    &sync_instance_id,
                )
                .await
            {
                tracing::warn!(
                    "Failed to reconcile synced options after closing {sync_instance_id}: {error}"
                );
            }
        });
        emit_process(
            &instance_id,
            uuid,
            ProcessPayloadType::Finished,
            "Exited process",
        )
        .await?;

        // Now fully complete- update playtime one last time
        update_playtime(&mut last_updated_playtime, &instance_id, true).await;

        // Publish play time update
        // Allow failure, it will be stored locally and sent next time
        // Sent in another thread as first call may take a couple seconds and hold up process ending
        let playtime_instance_id = instance_id.clone();
        tokio::spawn(async move {
            if let Err(e) =
                crate::api::instance::try_update_playtime_by_instance_id(
                    &playtime_instance_id,
                )
                .await
            {
                tracing::warn!(
                    "Failed to update playtime for instance {}: {}",
                    playtime_instance_id,
                    e
                );
            }
        });

        let logs_folder = state.directories.instance_logs_dir(&instance_path);
        let log_path = logs_folder.join(LAUNCHER_LOG_PATH);

        if log_path.exists()
            && let Err(e) = Process::append_to_log_file(
                &log_path,
                &format!("\n# Process exited with status: {mc_exit_status}\n"),
            )
        {
            tracing::warn!("Failed to write exit status to log file: {}", e);
        }

        let _ = state.discord_rpc.clear_activity().await;

        // If in tauri, window should show itself again after process exists if it was hidden
        #[cfg(feature = "tauri")]
        {
            let window = crate::EventState::get_main_window().await?;
            if let Some(window) = window {
                window.unminimize()?;
                window.set_focus()?;
            }
        }

        if mc_exit_status.success() {
            // We do not wait on the post exist command to finish running! We let it spawn + run on its own.
            // This behaviour may be changed in the future
            if let Some(hook) = post_exit_command {
                let mut cmd = shlex::split(&hook)
                    .ok_or_else(|| {
                        crate::ErrorKind::LauncherError(format!(
                            "Invalid post-exit command: {hook}",
                        ))
                    })?
                    .into_iter();

                if let Some(command) = cmd.next() {
                    let mut command = Command::new(command);
                    command.args(cmd).envs(post_exit_env_vars).current_dir(
                        state.directories.instances_dir().join(&instance_path),
                    );
                    command.spawn().map_err(IOError::from)?;
                }
            }
        }

        Ok(())
    }
}
