//! Theseus settings file

use serde::{Deserialize, Serialize};
use sqlx::{Pool, Sqlite};
use std::collections::HashMap;

// Types
/// Global Theseus settings
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Settings {
    pub max_concurrent_downloads: usize,
    pub max_concurrent_writes: usize,

    pub theme: Theme,
    pub locale: String,
    pub default_page: DefaultPage,
    pub collapsed_navigation: bool,
    pub hide_nametag_skins_page: bool,
    pub advanced_rendering: bool,
    pub native_decorations: bool,
    pub toggle_sidebar: bool,
    pub sync_theme_across_devices: bool,
    pub sync_behavior_across_devices: bool,
    #[serde(default = "default_true")]
    pub sync_features_across_devices: bool,
    #[serde(default = "default_true")]
    pub show_files_tab_in_instances: bool,
    #[serde(default = "default_true")]
    pub show_worlds_tab_in_instances: bool,
    #[serde(default)]
    pub show_screenshots_tab_in_instances: bool,
    #[serde(default = "default_true")]
    pub show_skin_selector_in_sidebar: bool,

    pub telemetry: bool,
    pub discord_rpc: bool,
    pub personalized_ads: bool,

    pub extra_launch_args: Vec<String>,
    pub custom_env_vars: Vec<(String, String)>,
    pub memory: MemorySettings,
    pub force_fullscreen: bool,
    pub game_resolution: WindowSize,
    pub hide_on_process_start: bool,
    pub hooks: Hooks,

    pub custom_dir: Option<String>,
    pub prev_custom_dir: Option<String>,
    pub migrated: bool,

    pub developer_mode: bool,
    pub feature_flags: HashMap<FeatureFlag, bool>,

    pub skipped_update: Option<String>,
    pub pending_update_toast_for_version: Option<String>,
    pub auto_download_updates: Option<bool>,

    pub version: usize,
}

fn default_true() -> bool {
    true
}

#[derive(Serialize, Deserialize, Debug, Clone, Copy, Eq, Hash, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum FeatureFlag {
    PagePath,
    ProjectBackground,
    WorldsInHome,
    ServerRamAsBytesAlwaysOn,
    AlwaysShowAppControls,
    AlwaysShowDownloadManager,
    ShowSyncInstancesUpdateModal,
    SkipUnknownPackWarning,
    PrideFundraiser,
    ServersInApp,
    ServerProjectQa,
    I18nDebug,
    ShowInstancePlayTime,
    CompactInstanceCards,
    SkipNonEssentialWarnings,
    AdvancedFiltersCollapsed,
    AlwaysShowCopyDetails,
    HideInstalledModpacks,
    FriendsActiveCollapsed,
    FriendsOnlineCollapsed,
    FriendsOfflineCollapsed,
    FriendsPendingCollapsed,
    DismissedPhotosensitivityFilterWarning,
    LocalhostSignIn,
    /// Retired (the in-game nickname badge was removed). Kept so settings
    /// saved by older versions still load.
    MinekubeCompanion,
    /// Minekube Shield strict mode: also blocks Modrinth's API and image CDNs.
    ShieldStrict,
    /// Runs the Minecraft process without direct network access.
    ShieldGameIsolation,
    /// Installs No Telemetry and No Chat Reports into modded instances.
    ShieldGameMods,
    /// Retired: shared logs are now always anonymized. Kept so settings
    /// saved by older versions still load.
    ShieldAnonymousLogs,
}

impl Settings {
    /// Whether Minekube Shield strict mode is on.
    pub fn shield_strict(&self) -> bool {
        self.feature_flags
            .get(&FeatureFlag::ShieldStrict)
            .copied()
            .unwrap_or(false)
    }
}

impl Settings {
    const CURRENT_VERSION: usize = 4;

    pub async fn get(
        exec: impl sqlx::Executor<'_, Database = sqlx::Sqlite>,
    ) -> crate::Result<Self> {
        let res = sqlx::query!(
            "
            SELECT
                max_concurrent_writes, max_concurrent_downloads,
                theme, locale, default_page, collapsed_navigation, hide_nametag_skins_page, advanced_rendering, native_decorations,
                discord_rpc, developer_mode, telemetry, personalized_ads,
                json(extra_launch_args) extra_launch_args, json(custom_env_vars) custom_env_vars,
                mc_memory_max, mc_force_fullscreen, mc_game_resolution_x, mc_game_resolution_y, hide_on_process_start,
                hook_pre_launch, hook_wrapper, hook_post_exit,
                custom_dir, prev_custom_dir, migrated, json(feature_flags) feature_flags, toggle_sidebar,
                skipped_update, pending_update_toast_for_version, auto_download_updates,
				sync_theme_across_devices, sync_behavior_across_devices, sync_features_across_devices,
				show_files_tab_in_instances, show_worlds_tab_in_instances,
				show_screenshots_tab_in_instances, show_skin_selector_in_sidebar,
                version
            FROM settings
            "
        )
            .fetch_one(exec)
            .await?;

        Ok(Self {
            max_concurrent_downloads: res.max_concurrent_downloads as usize,
            max_concurrent_writes: res.max_concurrent_writes as usize,
            theme: Theme::from_string(&res.theme),
            locale: res.locale,
            default_page: DefaultPage::from_string(&res.default_page),
            collapsed_navigation: res.collapsed_navigation == 1,
            hide_nametag_skins_page: res.hide_nametag_skins_page == 1,
            advanced_rendering: res.advanced_rendering == 1,
            native_decorations: res.native_decorations == 1,
            toggle_sidebar: res.toggle_sidebar == 1,
            telemetry: res.telemetry == 1,
            discord_rpc: res.discord_rpc == 1,
            developer_mode: res.developer_mode == 1,
            personalized_ads: res.personalized_ads == 1,
            extra_launch_args: res
                .extra_launch_args
                .as_ref()
                .and_then(|x| serde_json::from_str(x).ok())
                .unwrap_or_default(),
            custom_env_vars: res
                .custom_env_vars
                .as_ref()
                .and_then(|x| serde_json::from_str(x).ok())
                .unwrap_or_default(),
            memory: MemorySettings {
                maximum: res.mc_memory_max as u32,
                minimum: None,
            },
            force_fullscreen: res.mc_force_fullscreen == 1,
            game_resolution: WindowSize(
                res.mc_game_resolution_x as u16,
                res.mc_game_resolution_y as u16,
            ),
            hide_on_process_start: res.hide_on_process_start == 1,
            hooks: Hooks {
                pre_launch: res.hook_pre_launch,
                wrapper: res.hook_wrapper,
                post_exit: res.hook_post_exit,
            },
            custom_dir: res.custom_dir,
            prev_custom_dir: res.prev_custom_dir,
            migrated: res.migrated == 1,
            feature_flags: res
                .feature_flags
                .as_ref()
                .and_then(|x| serde_json::from_str(x).ok())
                .unwrap_or_default(),
            skipped_update: res.skipped_update,
            pending_update_toast_for_version: res
                .pending_update_toast_for_version,
            auto_download_updates: res.auto_download_updates.map(|x| x == 1),
            sync_theme_across_devices: res.sync_theme_across_devices == 1,
            sync_behavior_across_devices: res.sync_behavior_across_devices == 1,
            sync_features_across_devices: res.sync_features_across_devices == 1,
            show_files_tab_in_instances: res.show_files_tab_in_instances == 1,
            show_worlds_tab_in_instances: res.show_worlds_tab_in_instances == 1,
            show_screenshots_tab_in_instances: res
                .show_screenshots_tab_in_instances
                == 1,
            show_skin_selector_in_sidebar: res.show_skin_selector_in_sidebar
                == 1,
            version: res.version as usize,
        })
    }

    pub async fn update(
        &self,
        exec: impl sqlx::Executor<'_, Database = sqlx::Sqlite>,
    ) -> crate::Result<()> {
        let max_concurrent_writes = self.max_concurrent_writes as i32;
        let max_concurrent_downloads = self.max_concurrent_downloads as i32;
        let theme = self.theme.as_str();
        let default_page = self.default_page.as_str();
        let extra_launch_args = serde_json::to_string(&self.extra_launch_args)?;
        let custom_env_vars = serde_json::to_string(&self.custom_env_vars)?;
        let feature_flags = serde_json::to_string(&self.feature_flags)?;
        let version = self.version as i64;

        sqlx::query!(
            "
            UPDATE settings
            SET
                max_concurrent_writes = $1,
                max_concurrent_downloads = $2,

                theme = $3,
                locale = $4,
                default_page = $5,
                collapsed_navigation = $6,
                advanced_rendering = $7,
                native_decorations = $8,

                discord_rpc = $9,
                developer_mode = $10,
                telemetry = $11,
                personalized_ads = $12,

                extra_launch_args = jsonb($13),
                custom_env_vars = jsonb($14),
                mc_memory_max = $15,
                mc_force_fullscreen = $16,
                mc_game_resolution_x = $17,
                mc_game_resolution_y = $18,
                hide_on_process_start = $19,

                hook_pre_launch = $20,
                hook_wrapper = $21,
                hook_post_exit = $22,

                custom_dir = $23,
                prev_custom_dir = $24,
                migrated = $25,

                toggle_sidebar = $26,
                feature_flags = $27,
                hide_nametag_skins_page = $28,

                skipped_update = $29,
                pending_update_toast_for_version = $30,
                auto_download_updates = $31,

                sync_theme_across_devices = $32,
                sync_behavior_across_devices = $33,
				sync_features_across_devices = $34,
				show_files_tab_in_instances = $35,
				show_worlds_tab_in_instances = $36,
				show_screenshots_tab_in_instances = $37,
				show_skin_selector_in_sidebar = $38,

				version = $39
            ",
            max_concurrent_writes,
            max_concurrent_downloads,
            theme,
            self.locale,
            default_page,
            self.collapsed_navigation,
            self.advanced_rendering,
            self.native_decorations,
            self.discord_rpc,
            self.developer_mode,
            self.telemetry,
            self.personalized_ads,
            extra_launch_args,
            custom_env_vars,
            self.memory.maximum,
            self.force_fullscreen,
            self.game_resolution.0,
            self.game_resolution.1,
            self.hide_on_process_start,
            self.hooks.pre_launch,
            self.hooks.wrapper,
            self.hooks.post_exit,
            self.custom_dir,
            self.prev_custom_dir,
            self.migrated,
            self.toggle_sidebar,
            feature_flags,
            self.hide_nametag_skins_page,
            self.skipped_update,
            self.pending_update_toast_for_version,
            self.auto_download_updates,
            self.sync_theme_across_devices,
            self.sync_behavior_across_devices,
            self.sync_features_across_devices,
            self.show_files_tab_in_instances,
            self.show_worlds_tab_in_instances,
            self.show_screenshots_tab_in_instances,
            self.show_skin_selector_in_sidebar,
            version,
        )
        .execute(exec)
        .await?;

        Ok(())
    }

    pub async fn migrate(exec: &Pool<Sqlite>) -> crate::Result<()> {
        let mut settings = Self::get(exec).await?;

        if settings.version < Settings::CURRENT_VERSION {
            tracing::info!(
                "Migrating settings version {} to {:?}",
                settings.version,
                Settings::CURRENT_VERSION
            );
        }
        while settings.version < Settings::CURRENT_VERSION {
            if let Err(err) = settings.perform_migration() {
                tracing::error!(
                    "Failed to migrate settings from version {}: {}",
                    settings.version,
                    err
                );
                return Err(err);
            }
        }

        settings.update(exec).await?;

        Ok(())
    }

    pub fn perform_migration(&mut self) -> crate::Result<()> {
        match self.version {
            1 => {
                let quoter = shlex::Quoter::new().allow_nul(true);

                // Previously split by spaces
                if let Some(pre_launch) = self.hooks.pre_launch.as_ref() {
                    self.hooks.pre_launch =
                        Some(quoter.join(pre_launch.split(' ')).unwrap())
                }

                // Previously treated as complete path to command
                if let Some(wrapper) = self.hooks.wrapper.as_ref() {
                    self.hooks.wrapper =
                        Some(quoter.quote(wrapper).unwrap().to_string())
                }

                // Previously split by spaces
                if let Some(post_exit) = self.hooks.post_exit.as_ref() {
                    self.hooks.post_exit =
                        Some(quoter.join(post_exit.split(' ')).unwrap())
                }

                self.version = 2;
            }
            2 => {
                // Update old default memory setting from 2GB to 4GB (depending on system memory)
                const LEGACY_DEFAULT_MEMORY_MB: u32 = 2048;
                if self.memory.maximum == LEGACY_DEFAULT_MEMORY_MB {
                    self.memory.maximum =
                        crate::api::jre::default_memory_max_mb();
                }

                self.version = 3;
            }
            3 => {
                // Faster downloads: the old default of 10 parallel downloads
                // and writes left modern connections and SSDs idle. HTTP/2
                // multiplexes the extra downloads over the same connections,
                // and the API rate limiter still keeps Modrinth requests in
                // check. Values the player changed themselves are kept.
                const LEGACY_DEFAULT_CONCURRENCY: usize = 10;
                if self.max_concurrent_downloads == LEGACY_DEFAULT_CONCURRENCY {
                    self.max_concurrent_downloads = 24;
                }
                if self.max_concurrent_writes == LEGACY_DEFAULT_CONCURRENCY {
                    self.max_concurrent_writes = 16;
                }

                // Privacy by default: nothing is shared with a third party
                // unless the player turns it on. Discord Rich Presence tells
                // Discord what you are playing, so it starts off; it can be
                // enabled again under Settings → Privacy. The inherited
                // telemetry and personalised-ads flags are not used by this
                // launcher at all and are cleared for good measure.
                self.discord_rpc = false;
                self.telemetry = false;
                self.personalized_ads = false;

                self.version = 4;
            }
            version => {
                return Err(crate::ErrorKind::OtherError(format!(
                    "Invalid settings version: {version}"
                ))
                .into());
            }
        }

        Ok(())
    }
}

/// Theseus theme
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Theme {
    Dark,
    Light,
    Windows,
    Macos,
    Linux,
    Oled,
    Retro,
    Parchment,
    Ember,
    Abyss,
    Lagoon,
    Bloom,
    Nether,
    Cinder,
    System,
}

impl Theme {
    pub fn as_str(&self) -> &'static str {
        match self {
            Theme::Dark => "dark",
            Theme::Light => "light",
            Theme::Windows => "windows",
            Theme::Macos => "macos",
            Theme::Linux => "linux",
            Theme::Oled => "oled",
            Theme::Retro => "retro",
            Theme::Parchment => "parchment",
            Theme::Ember => "ember",
            Theme::Abyss => "abyss",
            Theme::Lagoon => "lagoon",
            Theme::Bloom => "bloom",
            Theme::Nether => "nether",
            Theme::Cinder => "cinder",
            Theme::System => "system",
        }
    }

    pub fn from_string(string: &str) -> Theme {
        match string {
            "dark" => Theme::Dark,
            "light" => Theme::Light,
            "windows" => Theme::Windows,
            "macos" => Theme::Macos,
            "linux" => Theme::Linux,
            "oled" => Theme::Oled,
            "retro" => Theme::Retro,
            "parchment" => Theme::Parchment,
            "ember" => Theme::Ember,
            "abyss" => Theme::Abyss,
            "lagoon" => Theme::Lagoon,
            "bloom" => Theme::Bloom,
            "nether" => Theme::Nether,
            "cinder" => Theme::Cinder,
            "system" => Theme::System,
            _ => Theme::System,
        }
    }
}

/// Minecraft memory settings
#[derive(Serialize, Deserialize, Debug, Clone, Copy)]
pub struct MemorySettings {
    pub maximum: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub minimum: Option<u32>,
}

impl MemorySettings {
    pub fn effective_minimum(&self) -> Option<u32> {
        self.minimum
            .filter(|minimum| *minimum > 0)
            .map(|minimum| minimum.min(self.maximum))
    }
}

/// Game window size
#[derive(Serialize, Deserialize, Debug, Clone, Copy)]
pub struct WindowSize(pub u16, pub u16);

/// Game initialization hooks
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
#[serde_with::serde_as]
pub struct Hooks {
    #[serde_as(as = "serde_with::NoneAsEmptyString")]
    pub pre_launch: Option<String>,
    #[serde_as(as = "serde_with::NoneAsEmptyString")]
    pub wrapper: Option<String>,
    #[serde_as(as = "serde_with::NoneAsEmptyString")]
    pub post_exit: Option<String>,
}

/// Opening window to start with
#[derive(Serialize, Deserialize, Debug, Clone, Copy)]
pub enum DefaultPage {
    Home,
    Library,
}

impl DefaultPage {
    pub fn as_str(&self) -> &'static str {
        match self {
            DefaultPage::Home => "home",
            DefaultPage::Library => "library",
        }
    }

    pub fn from_string(string: &str) -> Self {
        match string {
            "home" => Self::Home,
            "library" => Self::Library,
            _ => Self::Home,
        }
    }
}
