use crate::server_address::ServerAddress;
use crate::state::{
    Credentials, FeatureFlag, ProcessMetadata, Settings, State,
    game_options_sync_is_enabled, load_game_option_preferences,
};
use crate::util::io::IOError;
use tokio::process::Command;
use tracing::warn;

#[derive(Debug, Clone)]
pub enum QuickPlayType {
    None,
    Singleplayer(String),
    Server(ServerAddress),
}

#[tracing::instrument(skip(quick_play_type))]
pub async fn run(
    instance_id: &str,
    quick_play_type: QuickPlayType,
) -> crate::Result<ProcessMetadata> {
    let state = State::get().await?;
    if crate::state::instances::adapters::sqlite::instance_rows::is_instance_quarantined(
        instance_id,
        &state.pool,
    )
    .await?
    {
        return Err(crate::ErrorKind::InputError(
            "This instance has been quarantined".to_string(),
        )
        .into());
    }
    let settings = Settings::get(&state.pool).await?;
    let isolation_requested = settings
        .feature_flags
        .get(&FeatureFlag::ShieldGameIsolation)
        .copied()
        .unwrap_or(false);
    if !isolation_requested {
        {
            let _priority =
                state.content_store.legacy_migration_priority.write().await;
            crate::state::instances::commands::migrate_legacy_content(
                instance_id,
                &state,
                false,
            )
            .await?;
        }
        super::shared::check_shared_instance_availability_before_launch(
            instance_id,
            &state,
        )
        .await?;
    }
    let context =
        crate::state::instances::commands::get_instance_launch_context(
            instance_id,
            &state.pool,
        )
        .await?
        .ok_or_else(|| {
            crate::ErrorKind::OtherError(format!(
                "Tried to run a nonexistent instance {instance_id}!"
            ))
        })?;
    let instance_sync_preferences =
        crate::state::instances::adapters::sqlite::instance_rows::get_instance_sync_preferences(
            instance_id,
            &state.pool,
        )
        .await?;
    let fullscreen_is_shared = game_options_sync_is_enabled(&state.pool)
        .await?
        && instance_sync_preferences.game_options
        && load_game_option_preferences(&state.pool)
            .await?
            .get("fullscreen")
            .is_some_and(|preference| preference.enabled);
    if crate::state::instances::adapters::sqlite::instance_rows::is_instance_quarantined(
        instance_id,
        &state.pool,
    )
    .await?
    {
        return Err(crate::ErrorKind::InputError(
            "This instance has been quarantined".to_string(),
        )
        .into());
    }

    let isolation = if isolation_requested {
        if matches!(quick_play_type, QuickPlayType::Server(_)) {
            return Err(crate::ErrorKind::LauncherError(
                "Multiplayer is unavailable while game network isolation is enabled. Change it in Privacy to join a server.".to_owned(),
            )
            .into());
        }
        Some(
            crate::launcher::network_isolation::NetworkIsolation::prepare()
                .await?,
        )
    } else {
        None
    };
    let isolated = isolation.is_some();
    let credentials = if isolated {
        Credentials::get_active_without_refresh(&state.pool).await?
    } else {
        Credentials::get_default_credential(&state.pool).await?
    }
    .ok_or_else(|| crate::ErrorKind::NoCredentialsError.as_error())?;

    // Minekube Shield: the optional privacy mods (No Telemetry, No Chat
    // Reports) follow the player's choice before every launch.
    let shield_game_mods = settings
        .feature_flags
        .get(&FeatureFlag::ShieldGameMods)
        .copied()
        .unwrap_or(false);
    match crate::api::instance::get_full_path(instance_id).await {
        Ok(instance_path) => {
            // The retired nickname-badge mod is taken out of every instance.
            crate::launcher::shield_game::remove_retired_companion(
                &instance_path.join("mods"),
            )
            .await;
            if !isolated
                && let Err(error) = crate::launcher::shield_game::sync_privacy_mods(
                    &instance_path,
                    context.applied_content_set.loader,
                    &context.applied_content_set.game_version,
                    shield_game_mods,
                )
                .await
            {
                warn!("Could not prepare the Minekube Shield mods: {error}");
            }
        }
        Err(error) => {
            warn!("Could not prepare the Minekube Shield mods: {error}")
        }
    }

    let pre_launch_hook = context
        .launch_overrides
        .hooks
        .pre_launch
        .as_ref()
        .or(settings.hooks.pre_launch.as_ref())
        .filter(|hook_command| !isolated && !hook_command.is_empty());

    let mut java_args = context
        .launch_overrides
        .extra_launch_args
        .clone()
        .unwrap_or(settings.extra_launch_args);
    crate::launcher::shield_game::harden_jvm_args(&mut java_args);

    let wrapper = context
        .launch_overrides
        .hooks
        .wrapper
        .clone()
        .or(settings.hooks.wrapper)
        .filter(|hook_command| !isolated && !hook_command.is_empty());

    let env_args = context
        .launch_overrides
        .custom_env_vars
        .clone()
        .unwrap_or(settings.custom_env_vars);

    let post_exit_hook = context
        .launch_overrides
        .hooks
        .post_exit
        .clone()
        .or(settings.hooks.post_exit)
        .filter(|hook_command| !isolated && !hook_command.is_empty());

    let memory = context.launch_overrides.memory.unwrap_or(settings.memory);
    let resolution = context
        .launch_overrides
        .game_resolution
        .unwrap_or(settings.game_resolution);
    let has_hook_commands = pre_launch_hook.is_some()
        || wrapper.is_some()
        || post_exit_hook.is_some();
    let full_path = if has_hook_commands {
        Some(crate::util::io::canonicalize(
            state
                .directories
                .instances_dir()
                .join(&context.instance.path),
        )?)
    } else {
        None
    };
    let hook_environment = if has_hook_commands {
        let full_path = full_path
            .as_ref()
            .expect("hooked launches always resolve their instance path");
        let java_version =
            crate::launcher::resolve_java_for_launch(&context).await?;

        Some(crate::launcher::hooks::HookEnvironment::from_current_env(
            &env_args,
            crate::launcher::hooks::HookVariables {
                instance_name: context.instance.name.clone(),
                instance_id: context.instance.path.clone(),
                instance_dir: full_path.to_string_lossy().to_string(),
                java_path: java_version.path.clone(),
                java_args: crate::launcher::hooks::build_hook_java_args(
                    &java_args,
                    memory,
                    &java_version,
                ),
            },
        ))
    } else {
        None
    };
    let launch_env_args = hook_environment
        .as_ref()
        .map_or_else(|| env_args.clone(), |env| env.injected_envs());

    if let (Some(hook), Some(hook_environment), Some(full_path)) = (
        pre_launch_hook,
        hook_environment.as_ref(),
        full_path.as_ref(),
    ) {
        let expanded_hook = hook_environment.expand(hook);
        let mut cmd = shlex::split(&expanded_hook)
            .ok_or_else(|| {
                crate::ErrorKind::LauncherError(format!(
                    "Invalid pre-launch command: {hook}",
                ))
            })?
            .into_iter();

        if let Some(command) = cmd.next() {
            let result = Command::new(command)
                .args(cmd)
                .envs(launch_env_args.iter().cloned())
                .current_dir(full_path)
                .spawn()
                .map_err(|e| IOError::with_path(e, full_path))?
                .wait()
                .await
                .map_err(IOError::from)?;

            if !result.success() {
                return Err(crate::ErrorKind::LauncherError(format!(
                    "Non-zero exit code for pre-launch hook: {}",
                    result.code().unwrap_or(-1)
                ))
                .as_error());
            }
        }
    }

    let wrapper = wrapper
        .map(|hook| {
            hook_environment
                .as_ref()
                .map_or(hook.clone(), |env| env.expand(&hook))
        })
        .filter(|hook_command| !hook_command.is_empty());
    let post_exit_hook = post_exit_hook
        .map(|hook| {
            hook_environment
                .as_ref()
                .map_or(hook.clone(), |env| env.expand(&hook))
        })
        .filter(|hook_command| !hook_command.is_empty());

    let mut mc_set_options: Vec<(String, String)> = vec![];
    if let Some(fullscreen) = context.launch_overrides.force_fullscreen {
        mc_set_options.push(("fullscreen".to_string(), fullscreen.to_string()));
    } else if settings.force_fullscreen && !fullscreen_is_shared {
        mc_set_options.push(("fullscreen".to_string(), "true".to_string()));
    }

    if !isolated {
        crate::minecraft_skins::flush_pending_skin_change().await?;
    }
    crate::launcher::launch_minecraft(
        &java_args,
        &launch_env_args,
        &mc_set_options,
        &wrapper,
        &memory,
        &resolution,
        &credentials,
        post_exit_hook,
        &context,
        quick_play_type,
        isolation.as_ref(),
    )
    .await
}

pub async fn kill(instance_id: &str) -> crate::Result<()> {
    let state = State::get().await?;
    let processes =
        crate::api::process::get_by_instance_id(instance_id).await?;

    for process in processes {
        state.process_manager.kill(process.uuid).await?;
    }

    Ok(())
}

#[tracing::instrument]
pub async fn try_update_playtime_by_instance_id(
    instance_id: &str,
) -> crate::Result<()> {
    let state = State::get().await?;
    let context =
        crate::state::instances::commands::get_instance_launch_context(
            instance_id,
            &state.pool,
        )
        .await?
        .ok_or_else(|| {
            crate::ErrorKind::OtherError(format!(
                "Tried to update playtime for nonexistent instance {instance_id}!"
            ))
        })?;
    let updated_recent_playtime = context.instance.recent_time_played;

    // Minekube Shield: play time stays on this computer. The Modrinth base sent
    // every session's length, loader, game version and the installed mods'
    // versions to Modrinth's analytics; here it is only counted locally.
    crate::state::instances::commands::mark_instance_playtime_submitted(
        &context.instance.id,
        updated_recent_playtime,
        &state.pool,
    )
    .await?;

    Ok(())
}
